import java.util.Scanner;
class CheckCard {
    //get credit card number input
    public static void main(String[] args) {
        try (Scanner cardInfoRaw = new Scanner(System.in)) {
            System.out.println("Enter Credit Card Number");

        // convert into useable string
        String cardInfo = cardInfoRaw.nextLine();

        //convert into usable  long. also checks to ensure no alphabetical characters are inside of the card number.
        long cardInfoNum = 0;
        try {
            cardInfoNum = Long.parseLong(cardInfo);
        } catch (NumberFormatException e) {
            System.out.println("The information entered was not valid.");
            return;
        }
        
        //the program will have to check for prefixes later. it must start with 4, 5, 37, or 6. However it must be declatred now, as well as the following variables.
        String[] prefixes = {"4","5","37","6"};

        // the program will have to check for the result of the checked prefixes later.
        boolean result = false;

        // the program must have the length of the string in order for it to check for the prefixes. It gets this from calling cardInfo
        int length = cardInfo.length();

        // the program must add together the sum of some doubled digits later for validation. however we must intialize it now, so we must declare it.
        int totalDoubledDigits =0;

        // the program must add together the sum of the digits of every other number later. first we start off with, in the example, 54321, it counts 2 and 4. then, 1 3 and 5
        // for the program to do this, we have a countLoop variable. we must set it now.
        int countLoop = 2;

        // later, the program must add together every other number from left to right. for example, if 54321 was inputted, it would count 2 and 4 together, the first every other. then 1 3 and 5.
        // the second every other
        int firstOther = 0;
        int secondOther = 0;

        //process of checking whether or not the credit card is valid. 
        //if any of the checks are false, the loop will break and tell the user the information is false.
        boolean validation = true;

        //check for appropriate credit card length.
        if (cardInfo.length()>=17 || cardInfo.length() <=12) {
            validation = false;
        }

        //check for negative credit card number. if negative, set validation to false.
        if (cardInfoNum < 0) {
            validation = false;

        }

        //check to ensure that the credit card number starts with 4, 5, 37, or 6
        for (String prefix : prefixes) {
            if (cardInfo.startsWith(prefix)) {
                result = true;
                break;
            }
        }

        //if the card does not begin with the right prefix, it will be flagged as false.
        if (result != true) {
            validation = false;
        }

        // the loop is here because we have to count every other number twice. for example, if someone inputted "1234", the first time around it will count 3 and 1. multiply
        //each by 2, so 6 and 2, add it together. 8. then store it for later. then, it shifts over from 3 to 4. then every other number is counted starting from 4, but not multiplied
        //by 2. it is a loop in a loop bceause the process has to happen twice.
        while (countLoop >= 1) {

            //it checks how long the loop is, then subtracts countLoop. countLoop starts off as 2, so it then checks, in the "1234" example, 3. then does it again for the second loop, which
            //would be 4.
            for (int i = length - countLoop; i >= 0; i -=2 ) {

                //convert string to an integer so that it can be doubled. 
                int digit = Character.getNumericValue(cardInfo.charAt(i));

                //double the digit so that it can be added to the first half of the final number check. however, this is only done on the first loop. so we use countLoop.
                // the first time around its supposed to multiply the digits by 2. however, second time around it doesnt, so we just multiply the digit by 1, so it just stays the same
                int doubledDigit = digit * countLoop;

                //if the digit that is doubled is two digits long, for example 6 * 2 = 12, the digits must be added together. 
                //so 1 + 2 = 3, then the 3 will be added to the final number. that is what the code below does. it detects if the number is double digits
                if (doubledDigit >=10) {

                //first you have to convert it to a string, so you can locate the digit and convert it into an int.
                    String doubledDigitStr = Integer.toString(doubledDigit);

                    //System.out.println("Accounting the double digit " + doubledDigitStr);
                    int firstDigit = Character.getNumericValue(doubledDigitStr.charAt(0));
                    int secondDigit = Character.getNumericValue(doubledDigitStr.charAt(1));

                    //second, you have to add the two digits together like in the 6 * 12 example, which this does.
                    int sumOfDoubledDigits = firstDigit + secondDigit;

                    // now that you have your new number, you add it to the rest of the first half of the final number.
                    totalDoubledDigits += sumOfDoubledDigits;
                }

                    // if the doubled digit is not two digits, it does not have to go through that process. instead, it takes upon this much simpler one:
                else {
                    totalDoubledDigits += doubledDigit;
                }
            }
            // this checks to see what the countLoop is on. if it is 2, it stores the digit for firstOther to be added towards the final calculation
            if (countLoop == 2) {
                firstOther = totalDoubledDigits;
                }       

            // this does the same as the above, but for the secondOther
            if (countLoop == 1) {
                secondOther = totalDoubledDigits;
            }
            // this makes the countLoop go down. which is very important, because it helps determine the odd numbers for every other and evens. it also 
            // tells the loop how many more times it has to loop. totalDoubledDigits is also set to 0 so that it can be fresh for the next loop.
            countLoop--;
            totalDoubledDigits = 0;
        }
         //we add together the numbers of firstOther and secondOther so that it can be divided by 10. if it cannot, the validation is false. if it can, the card is valid.
        // so we do not mark it as false.
        if ((firstOther + secondOther) % 10 != 0) {
            validation = false;
        }

        //if validation is false at any time, this message will be put onto the terminal:
        if (validation == false) {
            System.out.println("The information entered was not valid.");

        //if it is valid, then this message will be on the terminal instead:
        }else{
            System.out.println("The information entered was valid.");
        }
        }
    }
}